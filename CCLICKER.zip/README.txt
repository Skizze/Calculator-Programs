Cookie Clicker is a simple game to play.
Once on your calculator, simply start the game, choose "New Game"
Press "Mode" to view all controls
If your calculator crashes for any reason, select "Yes" on the opening screen.
If you find any bugs, or have any suggestions, message me please.
Have fun!