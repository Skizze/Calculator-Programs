SPYTOWER
Beta 1.0
-------------------
Controls:
Movement-Arrow Keys
Enter-2nd
Back-Alpha
-------------------
How to play:
1. Choose a difficulty
2. Press 'Play'
3. Choose a way to play
4. Take test
5. Have fun!
-------------------
Ways to play:
1. Memory
You can try to remember
all of the numbers and
positions. This way gets
very hard very fast.

2. Notepad
You can use a notepad
to write down the numbers
and positions, and see
how good your note-taking
skills are!
-------------------
Settings navigation:

Presets:
Presets are preloaded
settings for the other 
2 options. You can
always mix and match
though!

Floors:
Floors are how many
levels you pass before
the test begins

Difficulty:
Difficulty is how hard
the test is.

Difficulty 1-only 1 number on each level

Difficulty 2-1 number per level AND positions are added

Difficulty 3-2 numbers per level with positions
--------------------
Notes:
This game can get very, very hard.

There may be bugs, just none that
should completely ruin the game.

When on difficulty 3, there are
2 numbers on each level, each
counting separately on the test
--------------------
Test info:

The test randomly generates the questions

The test can NOT repeat questions

The amount of test questions is based off
of the difficulty you chose
---------------------
Contest info:
This game was written in pure TI-Basic
and is meant for the TI-84 Plus CE
---------------------
P.S.
Thank you for your support through the creation
of this game, as I almost quit multiple times.
I was very busy during the time frame, but some
people kept me inspired, even though they might
not know just how much of an impact it had on
my motivation.
                   -Thank you!
