MINESWEEPER
V 1.0
--------------------
Made by:
Skizze
--------------------
Controls:
Alpha:Flag
2nd:Detonate(select)
Arrow Keys:Move Cursor
--------------------
Symbols:
Flag:?
Mine:!
Cursor:+
--------------------
Additional Features:
You can't accidentally
click a bomb once you've
flagged it.
--------------------
No bugs are currently known
--------------------
Calculator Compatability:
TI 83 and 84 series including TI 84 plus CE
--------------------
Have Fun!